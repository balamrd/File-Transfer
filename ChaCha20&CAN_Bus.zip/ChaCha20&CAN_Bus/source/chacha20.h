
/*===========================================================================*/
/**
 * @file        chacha20.h
 * @version     V1.0
 * @author      Continental Automotive
 * @brief       Header for chacha20.c module
 */
/*===========================================================================*/

#ifndef CHACHA20_H
#define CHACHA20_H
         
#include <stdio.h>
#include "r_cg_macrodriver.h"

#ifdef __cplusplus
extern "C" {
#endif
/* ------------------------------------------------------------------------- */

/*
 * The following macros are used to obtain exact-width results.
 */

#define U8V(v) ((uint8_t)(v) & (0xFF))
#define U16V(v) ((uint16_t)(v) & (0xFFFF))
#define U32V(v) ((uint32_t)(v) & (0xFFFFFFFF))


/* ------------------------------------------------------------------------- */

/*
 * The following macros return words with their bits rotated over n
 * positions to the left/right.
 */

#define ECRYPT_DEFAULT_ROT

#define ROTL8(v, n) \
  (U8V((v) << (n)) | ((v) >> (8 - (n))))

#define ROTL16(v, n) \
  (U16V((v) << (n)) | ((v) >> (16 - (n))))

#define ROTL32(v, n) \
  (U32V((v) << (n)) | ((v) >> (32 - (n))))


#define ROTR8(v, n) ROTL8(v, 8 - (n))
#define ROTR16(v, n) ROTL16(v, 16 - (n))
#define ROTR32(v, n) ROTL32(v, 32 - (n))

    

/* ------------------------------------------------------------------------- */
/*
 * The following macros load words from an array of bytes with
 * different types of endianness, and vice versa.
 */


#define U8TO16_LITTLE(p) \
  (((uint16_t)((p)[0])      ) | \
   ((uint16_t)((p)[1]) <<  8))

#define U8TO32_LITTLE(p) \
  (((uint32_t)((p)[0])      ) | \
   ((uint32_t)((p)[1]) <<  8) | \
   ((uint32_t)((p)[2]) << 16) | \
   ((uint32_t)((p)[3]) << 24))

#define U8TO16_BIG(p) \
  (((uint16_t)((p)[0]) <<  8) | \
   ((uint16_t)((p)[1])      ))

#define U8TO32_BIG(p) \
  (((uint32_t)((p)[0]) << 24) | \
   ((uint32_t)((p)[1]) << 16) | \
   ((uint32_t)((p)[2]) <<  8) | \
   ((uint32_t)((p)[3])      ))

#define U16TO8_LITTLE(p, v) \
  do { \
    (p)[0] = U8V((v)      ); \
    (p)[1] = U8V((v) >>  8); \
  } while (0)

#define U32TO8_LITTLE(p, v) \
  do { \
    (p)[0] = U8V((v)      ); \
    (p)[1] = U8V((v) >>  8); \
    (p)[2] = U8V((v) >> 16); \
    (p)[3] = U8V((v) >> 24); \
  } while (0)


/* ------------------------------------------------------------------------- */


/**
 * context-struct
 */
typedef struct chacha20_context
{
  /*
   * Put here all state variable needed during the encryption process.
   */
  uint32_t input[16]; /* The internal state is made of sixteen 32-bit words arranged as a 4�4 matrix */
} Chacha20_ctx;


/**
 * initial state setup with key
 *
 * @param x         chacha20 context-struct
 * @param key       key (default: 256-bit)
 * @param keysize   key-length in bit
 * @param ivsize    IV-size in bit
 */
void Chacha20_keysetup(Chacha20_ctx *x,const uint8_t *key,uint32_t keysize,uint32_t ivsize);


/**
 * initial state setup with iv
 *
 * @param x         chacha20 context-struct
 * @param iv        IV (default: 64-bit)
 */
void Chacha20_ivsetup(Chacha20_ctx* x, const uint8_t* iv);


/**
 * keystream generation from current state
 *
 * @brief For testing purposes it can sometimes be useful to have a function
 *        which immediately generates keystream without having to provide it
 *        with a zero plaintext.
 *
 * @param keystream    array containing the resulted keystream (default: 512-bit)
 * @param input        array containing the current chacha20 state (default: 512-bit)
 */
void Chacha20_keystream(uint8_t keystream[64],const uint32_t input[16]);


/**
 * encrypt message with keystream
 *
 * @param x             chacha20 context-struct
 * @param message       8-bit array containing the message to be encrypted (plaintext)
 * @param ciphertext    8-bit array to contain the ciphertext generated from the encryption
 * @param msglen        message length in bytes
 */
void Chacha20_encrypt_bytes(Chacha20_ctx *x, const uint8_t *message, uint8_t *ciphertext, uint32_t msglen);


/**
 * decrypt message with keystream
 *
 * @param x             chacha20 context-struct
 * @param ciphertext    8-bit array to contain the ciphertext generated from the encryption
 * @param message       8-bit array containing the message to be encrypted (plaintext)
 * @param msglen        message length in bytes
 */
void Chacha20_decrypt_bytes(Chacha20_ctx *x, const uint8_t *ciphertext, uint8_t *message, uint32_t msglen);

void print_state(Chacha20_ctx *x);

#ifdef __cplusplus
}
#endif

#endif // #ifndef CHACHA20_H
