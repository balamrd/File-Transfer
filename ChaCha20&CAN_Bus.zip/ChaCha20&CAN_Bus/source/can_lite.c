/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2012, 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_port.h"
#include "r_cg_userdefine.h"
#include <stdio.h>

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
static void RxRule_Set(void);
void Clear_DataBuffer0(void);


/***********************************************************************************************************************
* Function Name: CAN-Init
* Description  : This function initialise can lite bus.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CAN_Init(void)
{
        /* ---------- CAN port settings --------- */
        
        //Ctxd pin (P10)
        PIOR1 &= 0xFE;
        POM1 &= 0xFE;
        PM1 &= 0xFE;
        P1 |= 0x01;
    
        //Crxd pin (p11)
        PIOR1 &= 0xFD;
        PM1 |= 0x02;
        PIM1 &= 0xFD;
        PITHL1 &= 0xFD;
        
        
        /* ---------- Enable the CAN module -------- */
        
	PER2 |= 0x01;		//Enable CAN input clock supply
        //CANCKSEL |= 0x01;	//Set this bit when fx is used as main clock, comment it out when fclk is used as main clock
        	
	while(GSTS & 0x0008);	//Wait for RAM initialization process to be completed
        
        
        /* ---------- Transition to Reset Mode ------- */
        
	GCTRL |= 0x0004;        // Initial mode is Global Stop Mode
	C0CTRL |= 0x0004;       // Initial channel mode is Channel Stop Mode
	GCTRL &= 0xFFFB; 	// Global Stop Mode --> Global Reset Mode
        while(GSTS & 0x0004);   // Confirm the transition of CAN global reset mode
	C0CTRL &= 0xFFFB;	// Channel Stop Mode --> Channel Reset Mode
        while(C0STSL & 0x0004); // Confirm the transition to the CAN channel reset mode
        

        /* ---------- CAN Global and Channel setting ------- */

	// CAN Global Configuration Register L setting (pg. 1279 in hardware manual)
        /*  Timestamp clock not divided
            CAN Clock source is from the main clock frequency-divide by 2, Fcan = Fclk/2 --> since Fclk is 32MHz, Fcan = 16MHz
            Mirror function disabled
            DLC replacement is disabled
            DLC check is disabled
            Transmit priority is ID priority */
        GCFGL = 0x0000;	

//        GCFGL |= 0x0008;      // Uncomment this line to have mirror function enabled	
        
        // CAN Global Configuration Register L setting (pg. 1281 in hardware manual)
	GCFGH = 0x0001;		//Prescaler set 1 (for interval timer)
           	
        // CANi Bit Configuration Register H setting (pg. 1266 in hardware manual)
	C0CFGH = 0x001C; 	// Tseg1 = 13Tq, Tseg2 = 2Tq, SJW= 1Tq, --> total bit time = 16Tq
        
        // CANi Bit Configuration Register L setting (pg. 1265 in hardware manual)
	C0CFGL = 0x0007;	// Baudrate Prescaler division = 7+1 = 8
        
        //  Based on the setting above, Baudrate (communication speed)= Fcan/(prescaler*bit time) = 16MHz/(8 *(13+2+1)) = 0.125Mbps
        // the communication speed formula above can be seen in the manual pg. 1385
	

        /* ---------- Receive Rule set ------- */
        
	RxRule_Set();
        
        
        /* ---------- CAN Buffer setting ------- */

	/*Buffer Setting*/
	//RMNB = 0x0010; 		// 16 receive buffers are used, no receive FIFO used
        
        // Use the 2 lines below if you would like to use the receive FIFO buffers instead
        RMNB = 0x00;            // No receive buffers are used
        RFCC0 = 0x1302;         // Use the FIFO buffer, 16 messages can be stored there, enable the interrupt and set it's trigger to receiving a message         
        
        	
        /* ---------- CAN interrupt setting ------- */

	/*Global Interrupt*/
	GCTRL &= 0xF8FF;	//Disable all the interrupts
        
        CANGRFRIF = 0U;     /* clear INTCANGRFR interrupt flag */
        CANGRFRMK = 0U;     /* enable INTCANGRFR operation */
	
	/*Channel Interrupt*/
	C0CTRL &= 0x00FF;
	
        
        /* ---------- Transition to communication mode ------- */
        
        /* If GlobalChannel in halt or reset mode */
        if (GSTS & 0x03) 
        {
                GCTRL &= 0xfffffffc;    //Switch to global operating/communication mode
                while ((GSTS & 0x02) == 2)
                {
                /* While halt mode */
                }
                while ((GSTS & 0x01) == 1)
                {
                /* While reset mode */
                }
	
        }
        
        // Uncomment this line to modify the last bit of RFCC0 when in global operating mode to enable receive FIFO buffer
        RFCC0 |= 0x01;
        
        /* If Channel0 in halt or reset mode */
        if (C0STSL & 0x03) 
        {
                C0CTRL &= 0xfffffffc;    //Switch to channel communication mode
                while ((C0STSL & 0x02) == 2)
                {
                /* While halt mode */
                }
                while ((C0STSL & 0x01) == 1)
                {
                /* While reset mode */
                }
        }
        

    /*Port Setting*/
    //S pin of TJA1050 (output low)
    //P1 = _00_Pn2_OUTPUT_0;
    

}
/***********************************************************************************************************************
* Function Name: RxRule_Set
* Description  : This function set up the receive rule of can lite bus.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void RxRule_Set(void)
{
	int i;

    	uint16_t* RxRule_ID_H =(uint16_t*) &(GAFLIDH0);         // (pg. 1290)
	uint16_t* RxRule_ID_L =(uint16_t*) &(GAFLIDL0);         // (pg. 1289)
	uint16_t* RxRule_Mask_H =(uint16_t*) &(GAFLMH0);        // (pg. 1292)
	uint16_t* RxRule_Mask_L =(uint16_t*) &(GAFLML0);        // (pg. 1291)
    	uint16_t* RxRule_Entry_L = (uint16_t*) &(GAFLPL0);      // (pg. 1293)
	uint16_t* RxRule_Entry_H = (uint16_t*) &(GAFLPH0);      // (pg. 1294)
        
	uint16_t ID_H = 0x0000; // standard test mode
//        uint16_t ID_H = 0x2000; // self-test mode	
	uint16_t ID_L= 0x0010;
    	uint16_t EntryData = 0x8000;
	
	GAFLCFG |= 0x0010; 	//Channel 0 receive rule =16
	GRWCR &= 0xFFFE; 	//Select CAN RAM window 0 to get access to receive rule entry register
	
        // To make 16 receive rules
	for (i=0; i<16;i++)
	{
                
		*RxRule_ID_H= ID_H;     // 0x0000 --> id format(IDE bit): standard id, frame format(RTR bit): data frame, targetted message is from another CAN node
                // note: ID in standard id format is 11 bit long, in extended id format is 29 bit long
                
		*RxRule_ID_L= ID_L;     // These bits are used to set the ID field of each of the receive rule.
                
		*RxRule_Mask_H = 0xC000;  // IDE bit and RTR bit are compared (no mask)
                
		*RxRule_Mask_L = 0x07FF;  // No masking, compare all the ID field (11 bits, since it's standard id format)
                
                /* By the above rules, during the acceptance filter processing, the bits that are going to be compared between the rule and the received message
                   are: ID field (bit 0 to bit 11), IDE bit, and RTR bit*/
                
                
		//*RxRule_Entry_L = EntryData;    // receive buffers are used, set receive buffer number 1 for rule 1, number 2 for rule 2, etc.
                                                  // 0x8000 ==> starting from RMDF0n (0xF03A8) -- (pg. 1301)               
                *RxRule_Entry_L = 0x0001;         // Uncomment this line to use the receive FIFO buffer 0 only for all 16 rules -- RFDF0n
                        
		*RxRule_Entry_H = 0x0000;         // DLC checking is disabled, no need label for now
		
                // A pointer addition means passing to some next pointed element. So the address is incremented by the sizeof the pointed element.
                // Since the size of the pointed register is 2 bytes, so incrementing by 0x06 is equivalent to mathematically increment by 0x0C
		RxRule_ID_H += 0x06;
		RxRule_ID_L += 0x06;
		RxRule_Mask_H += 0x06;
		RxRule_Mask_L += 0x06;
		RxRule_Entry_L += 0x06;
		RxRule_Entry_H += 0x06;
		ID_L += 0x10;                   // The receive rules can accept messages with ID 0x10, 0x20, ..., 0xF0
		EntryData +=0x100;	
	}
	
	GRWCR |= 0x0001;		// Receive rule change completed, select CAN RAM window 1 
        
        
        /* The 2 line below are for me to check whether if I switch between window 0 and window 1, 
            will the rule setting which I set in window 0 still be preserved when I move to window 1 
            and then back to window 0? and the answer is yes. */
        
//        GRWCR &= 0xFFFE; 	        //Select window 0 to get access to receive rule entry register
//        GRWCR |= 0x0001;		//Select window 1 
}

/***********************************************************************************************************************
* Function Name: CAN_TxBuffer0
* Description  : This function sends the data from the transmit buffer 0 to the Bus
* Arguments    : TxData1        Data to be transmitted byte 1 & 2 
                 TxData2        Data byte 3 & 4
                 TxData3        Data byte 5 & 6
                 TxData4        Data byte 7 & 8
                 TxID           Data ID
* Return Value : None
***********************************************************************************************************************/
void CAN_TxBuffer0(uint16_t TxData1,uint16_t TxData2,uint16_t TxData3,uint16_t TxData4,uint16_t txID)
{
        //uint8_t i;
        //uint32_t  Databuf_adr = 0x00000000;

        while ((TMSTS0 & 0x01)!= 0x00);          // Make sure that there is no transmission in progress
        
        TMSTS0 &= 0xF9;                          // set TMTRF flag as B'00 to allow next message transmission from this buffer

        TMIDL0 = 0x00U;		                 // clear ID buffer

        Clear_DataBuffer0();

        TMDF00 = TxData1;
        TMDF10 = TxData2;		        // save tx data into data buffer register
        TMDF20 = TxData3;
        TMDF30 = TxData4;
        TMIDL0 = txID;		                // save ID into register
        TMIDH0 = 0x0000;
        TMPTR0 = 0x8000;		        // 8 data bytes to be transmitted
        TMC0 |= 0x01; 	        	        // Transmission requested
    
        while (TMSTS0 != 0x04);                 // wait until transmission is successful
        
}

void Clear_DataBuffer0(void)
{   
        uint8_t i;
        uint16_t* Databuf_adr = (uint16_t*) &(TMDF00);
        for(i=0U;i<4U;i++)
        {
        *Databuf_adr = 0U;
        Databuf_adr++;
        } 
}


/***********************************************************************************************************************
* Function Name: CAN_SelfTest0
* Description  : This function sets up the Self Test Mode 0 (External Feedback Mode)
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CAN_SelfTest0(void) {
        
        /* ---------- Self Test Mode setup ------- */
        
        // Transition to channel halt mode
        C0CTRL |= 0x02;
        
        while ((C0STSL & 0x02) != 2); // Confirm the transition to the CAN channel halt mode
        
        // Communication test mode is enabled, Self-test mode 0 is selected
        C0CTRH |= 0x0500;
                
         /* ---------- Transition to communication mode ------- */
        
        /* If GlobalChannel in halt or reset mode */
        if (GSTS & 0x03) 
        {
                GCTRL &= 0xfffffffc;    //Switch to communication mode
                while ((GSTS & 0x02) == 2)
                {
                /* While halt mode */
                }
                while ((GSTS & 0x01) == 1)
                {
                /* While reset mode */
                }
	
        }
        /* If Channel0 in halt or reset mode */
        if (C0STSL & 0x03) 
        {
                C0CTRL &= 0xfffffffc;    //Switch to communication mode
                while ((C0STSL & 0x02) == 2)
                {
                /* While halt mode */
                }
                while ((C0STSL & 0x01) == 1)
                {
                /* While reset mode */
                }
        }
}


/***********************************************************************************************************************
* Function Name: print_hex
* Description  : This function prints it's arguments in hexadecimal format
* Arguments    : msg            string to be printed before the data
                 data           array of data
                 length         length of data in bytes
* Return Value : None
***********************************************************************************************************************/
	
void print_hex_16(const char *msg, const uint16_t *data, int length)
{
          int i = 0;
          if (msg)
          {
            printf("%s: ", msg);
          }
          for (i = 0; i < length; i++)
          {
            if ((i % 8) == 0)
            {
              printf("\n");
            }
            printf("%04X ", data[i]);
          }
          printf("\n");
}


void print_hex_8(const char *msg, const unsigned char *data, int length)
{
  int i = 0;

  if (msg)
  {
    printf("%s: ", msg);
  }

  for (i = 0; i < length; i++)
  {
    if ((i % 16) == 0)
    {
      printf("\n");
    }
    printf("%02X ", data[i]);
  }
  printf("\n");
}

/***********************************************************************************************************************
* Function Name: Delay_ms
* Description  : This function is to produce delay
* Arguments    : i      Duration of delay in ms
* Return Value : None
***********************************************************************************************************************/
void Delay_ms(uint8_t i)    /*delay per ms*/
{
 uint16_t k;
  while(i > 0U)
  {
    i--;
    for(k=0U;k<3580U;k++) {
    }
  }
}