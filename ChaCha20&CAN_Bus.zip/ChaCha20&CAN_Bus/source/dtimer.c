
/*===========================================================================*/
/**
 * @file        dtimer.c
 * @version     V1.0
 * @author      Continental Automotive
 * @brief       This file contains the code for using the timer function of
 *              the microcontroller r5f10ppj
 */
/*===========================================================================*/

/* IAR Systems Includes                                                      */
#include <ior5f10ppj.h>
#include <ior5f10ppj_ext.h>

/* Application Includes                                                      */
#include <stdio.h>
#include "r_cg_macrodriver.h"
#include "dtimer.h"

/* Variable Declaration                                                     */
uint16_t T1, wd = 0;
uint8_t systick[16];          /* 16-bit Timer */

/* -------------------------------------------------------------------------*/
/* Timer Configuration                                                      */
/* -------------------------------------------------------------------------*/
uint16_t getTimer00Value()                      /* TCR00: Timer 0 Channel 0 */
{
  T1 = TCR00;
  return T1;                                    /* Return count value       */
  //printf("%u\n", T1);
}

void StartTimer(void) {
  TS0    |= 0x0001u;                                    /* start timer TM00 */                       
  int c, d;
  
  if(TPS0 > 0x0003u) {
   for (c = 1; c <= 100; c++)
       for (d = 1; d <= 100; d++)
       {}
  }
}

void StopTimer(void)  {
  TT0    |= 0x0AFFu;                      /* stop timer TM00 & all channels */                        
}

//void toggleLED(void)  {
//  if (T1 < 0x0001u) 
//  {
//  LED01 = ~LED01;
//  }
//}

/*void FreqSelection(void) {
  TPS0    = 0x0004u;
}*/