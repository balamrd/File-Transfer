
/*===========================================================================*/
/**
 * @file        dtimer.h
 * @version     V1.0
 * @author      Continental Automotive
 * @brief       Header for dtimer.c module
 */
/*===========================================================================*/

/* Prototype Functions */

uint16_t getTimer00Value();     /* TCR00: Timer 0 Channel 0 */

void StartTimer(void);          /* TS0: Start Timer 0       */
void StopTimer(void);           /* TS0: Stop Timer 0        */

void toggleLED(void);

//void FreqSelection(void);