
/*===========================================================================*/
/**
 * @file        chacha20.c
 * @version     V1.0
 * @author      Continental Automotive
 * @brief       This file contains the code for Chacha20 encryption, made based
                on the source code available on Ecrypt website
                https://www.ecrypt.eu.org/stream/e2-salsa20.html
 */
/*===========================================================================*/

#include "chacha20.h"

#define ECRYPT_LITTLE_ENDIAN

#define ROTATE(v,c) (ROTL32(v,c))
#define XOR(v,w) ((v) ^ (w))
#define PLUS(v,w) (U32V((v) + (w)))
#define PLUSONE(v) (PLUS((v),1))

#define QR(a, b, c, d) (			\
	a = PLUS(a , b),  d = XOR(d, a),  d = ROTATE(d,16),	\
	c = PLUS(c, d),  b = XOR(b, c),  b = ROTATE(b,12),	\
	a = PLUS(a, b),  d = XOR(d, a),  d = ROTATE(d, 8),	\
	c = PLUS(c, d),  b = XOR(b, c),  b = ROTATE(b, 7))


//input is a 16 word (32-bit) matrix
//output is a 64 byte (8-bit) keystream
void Chacha20_keystream(uint8_t output[64],const uint32_t input[16])
{
  uint32_t x[16];
  int i;

  for (i = 0;i < 16;++i) x[i] = input[i];
  for (i = 20;i > 0;i -= 2) {
  	// Odd round
	QR(x[ 0], x[ 4], x[ 8], x[12]); // column 0
	QR(x[ 1], x[ 5], x[ 9], x[13]); // column 1
	QR(x[ 2], x[ 6], x[10], x[14]); // column 2
	QR(x[ 3], x[ 7], x[11], x[15]); // column 3
	// Even round
	QR(x[ 0], x[ 5], x[10], x[15]); // diagonal 1 (main diagonal)
	QR(x[ 1], x[ 6], x[11], x[12]); // diagonal 2
	QR(x[ 2], x[ 7], x[ 8], x[13]); // diagonal 3
	QR(x[ 3], x[ 4], x[ 9], x[14]); // diagonal 4
  }
  for (i = 0;i < 16;++i) x[i] = PLUS(x[i],input[i]);
  for (i = 0;i < 16;++i) U32TO8_LITTLE(output + 4 * i,x[i]);
}


// The state for ChaCha20 also requires a 128-bit constant

// Below is the default constant word, but it can also be changed to any other constant
 //  static const char sigma[16] = "expand 32-byte k";
 //  static const char tau[16] = "expand 16-byte k";

void Chacha20_keysetup(Chacha20_ctx *x,const uint8_t *k,uint32_t kbits,uint32_t ivbits)
{
//  static const char *constants;

  //key
  x->input[4] = U8TO32_LITTLE(k + 0);
  x->input[5] = U8TO32_LITTLE(k + 4);
  x->input[6] = U8TO32_LITTLE(k + 8);
  x->input[7] = U8TO32_LITTLE(k + 12);

  if (kbits == 256) {                   // recommended
    k += 16;
//    constants = sigma;
  } else {                              // kbits == 128
    k += 0;
//    constants = tau;
  }

  // key
  x->input[8] = U8TO32_LITTLE(k + 0);
  x->input[9] = U8TO32_LITTLE(k + 4);
  x->input[10] = U8TO32_LITTLE(k + 8);
  x->input[11] = U8TO32_LITTLE(k + 12);

  // constants
  // x->input[0] = U8TO32_LITTLE(constants + 0);
  // x->input[1] = U8TO32_LITTLE(constants + 4);
  // x->input[2] = U8TO32_LITTLE(constants + 8);
  // x->input[3] = U8TO32_LITTLE(constants + 12);

  // we use this value to match the constant value from the website https://asecuritysite.com/encryption/chacha
  x->input[0] = 1634760805;
  x->input[1] = 857760878;
  x->input[2] = 2036477234;
  x->input[3] =  1797285236;
}


void Chacha20_ivsetup(Chacha20_ctx *x,const uint8_t *iv)
{
  // nonce
  x->input[14] = U8TO32_LITTLE(iv + 0);
  x->input[15] = U8TO32_LITTLE(iv + 4);  
  
  // counter
  x->input[12] = 0;
  x->input[13] = 0;
}


 void Chacha20_encrypt_bytes(Chacha20_ctx *x, const uint8_t *m, uint8_t *c, uint32_t bytes)
 {
   uint8_t output[64];                          // array for storing the keystream
   int i;                                       // var for XOR loop
//   int j = 0;                                   // var for iteration counter

    if (!bytes) return;
    for (;;) {      
      
      // Each time a sequence of 64-byte message is encrypted with the keystream, the Counter value inside the Chacha state
      // is then incremented by 1, and a new keystream is generated from the new state for the next 64-byte sequence of the message
      
      Chacha20_keystream(output,x->input);
      x->input[12] = PLUSONE(x->input[12]);
      if (!x->input[12]) {
        x->input[13] = PLUSONE(x->input[13]);
      }
      // The if statement above will only be executed when the data inside input[12] is equal to 0
      // So, when the value inside input[12] already get incremented until 2^32, in which the next increment
      // will result in an overflow and the value inside input[12] becomes 0, the input[13] will get incremented
      // This goes along with the fact that the counter is a 64-bit value, with input[13] storing the most significant word
      
      if (bytes <= 64) {
        for (i = 0;i < bytes;++i) c[i] = m[i] ^ output[i];       
//        printf("Total number of iteration: %d\n", ++j);                       // uncomment if needed for debugging
        return;
      }
      for (i = 0;i < 64;++i) c[i] = m[i] ^ output[i];
      bytes -= 64;
      c += 64;
      m += 64;
//      j++;    
    }
 }

 void Chacha20_decrypt_bytes(Chacha20_ctx *x, const uint8_t *c, uint8_t *m, uint32_t bytes)
 {
   Chacha20_encrypt_bytes(x,c,m,bytes);
 }

void print_state(Chacha20_ctx *x)
{
  for (int i = 0; i < 16; i++)
  {
    printf("%lu\n", x->input[i]);
  }
}


