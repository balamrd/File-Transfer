/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2012, 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

 

/***********************************************************************************************************************
* File Name    : r_cg_intc_user.c
* Version      : CodeGenerator for RL78/F13 V2.03.03.01 [28 Oct 2018]
* Device(s)    : R5F10BMG
* Tool-Chain   : CCRL
* Description  : This file implements device driver for INTC module.
* Creation Date: 25/7/2019
***********************************************************************************************************************/

 

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_intc.h"
/* Start user code for include. Do not edit comment generated here */
#include "can_lite.h"
#include "chacha20.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"
#include "dtimer.h"
#include <stdio.h>
#include <string.h>

 

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
//#pragma inline_asm r_intc0_interrupt
//#pragma interrupt r_intc0_interrupt(vect=INTP0)
/* Start user code for pragma. Do not edit comment generated here */
__interrupt static void r_intc0_interrupt(void);

static __interrupt void TM00_isr (void);
/* End user code. Do not edit comment generated here */

 

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */

 


#define CHACHA20_KEYSIZE_BIT 256
#define CHACHA20_IVSIZE_BIT 64

 

uint16_t convertFrom8To16(uint8_t dataFirst, uint8_t dataSecond);

 

unsigned char message[40] = {"Continental Automotive Singapore"}; //Maximum message size is 40 bytes only
unsigned char cipherText[40] = {0};
unsigned char message8Byte[8];
uint16_t TxData[4] = {};

 

/* End user code. Do not edit comment generated here */

 
#pragma vector=INTTM00_vect
static __interrupt void TM00_isr (void) {
  TMIF00  = 0u;            /* clear INTTM00 interrupt flag        */
}

/***********************************************************************************************************************
* Function Name: r_intc0_interrupt
* Description  : This function is INTP0 interrupt service routine, which will call the CAN transmission function
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

 

#pragma vector = INTP0_vect
__interrupt static void r_intc0_interrupt(void)
{  
//    uint16_t beforeTransmission = 0, afterTransmission = 0;
    Delay_ms(80U);  /*Delay for debounce */
    R_INTC0_Stop();
    
    LED1=ON;
    LED2=ON;
    
//    StartTimer();
//    
//    beforeTransmission = getTimer00Value();
    
    printf("===Transmission Started===\n\n");
    
        /* ---------- Chacha20 Initialization -------------------- */
    
    /* key and iv setup */
    // 32-byte key
    uint8_t key[32] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};                       
    // 8-byte iv or nonce
    uint8_t iv[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    
    /* clear key-length and IV-size */
    uint32_t keysize = CHACHA20_KEYSIZE_BIT;
    uint32_t ivsize = CHACHA20_IVSIZE_BIT;
    
    /* define context-struct */
    Chacha20_ctx x;
    
    /* initialize state */
    Chacha20_keysetup(&x, key, keysize, ivsize);
    Chacha20_ivsetup(&x, iv);
   
    int msglen = strlen((char const*)message);
    
    printf("Message Text: %s\n\n", message);
    
    print_hex_8("Message Hex", message, msglen);
    
    
    Chacha20_encrypt_bytes(&x, message, cipherText, msglen);
    
    unsigned char* msgPtr = cipherText;
        
    while(msglen > 0) 
    {
        memset(message8Byte, '\0', sizeof(message8Byte));
        memset(TxData, '\0', sizeof(TxData));
        memcpy(message8Byte, msgPtr, 8);
        uint8_t n = 0;
        for (int i=0; i<8; i += 2) {
            TxData[n] = convertFrom8To16(message8Byte[i], message8Byte[i+1]);
            n++;
        }
        //print_hex_16("CAN_TX_DATA", TxData, n);               //uncomment if needed for debugging
        CAN_TxBuffer0(TxData[0],TxData[1],TxData[2],TxData[3],0x10);
        msgPtr += 8;
        msglen -= 8;
    }
    /* The message / ciphertext is in form of char (8bit). So, it will first be divided into 8-byte chunks, and then converted
       into an array of size 16bits before being transmitted. Because, CAN Takes 4 16bit data (8byte) every transmission */
    
    printf("\nCiphertext: %s\n\n",  cipherText);
    
    print_hex_8("Ciphertext Hex", cipherText, strlen((char const*)cipherText));
    
    printf("\n===Transmission Ended===\n\n\n");
    
//    afterTransmission = getTimer00Value();
//    printf("Transmission Clock Cycle: %u clocks\n", beforeTransmission - afterTransmission);
    
    LED1=OFF;
    LED2=OFF;           // LED on and off to signal that the message has been successfully transmitted
    R_INTC0_Start();
    
} 
    // after a fixed time interval, if there is no acknowledgement that the message have been received 
    // by another node(timeout), the protocol will automatically clear the interrupt and will go out of the handler function

 

 


uint16_t convertFrom8To16(uint8_t dataFirst, uint8_t dataSecond) {
    uint16_t dataCombined = 0x0000;
    dataCombined = dataFirst;
    dataCombined = dataCombined << 8;
    dataCombined |= dataSecond;
    return dataCombined;
}