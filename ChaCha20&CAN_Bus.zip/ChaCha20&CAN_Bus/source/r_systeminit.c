/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2012, 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_systeminit.c
* Version      : CodeGenerator for RL78/F13 V2.03.03.01 [28 Oct 2018]
* Device(s)    : R5F10BMG
* Tool-Chain   : CCRL
* Description  : This file implements system initializing function.
* Creation Date: 25/7/2019
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_cgc.h"
#include "r_cg_port.h"
#include "r_cg_intc.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Constants
***********************************************************************************************************************/

/* --------------------------------------------------------------------------*/
/* Option-bytes and security ID                                              */
/* --------------------------------------------------------------------------*/
#define OPT_BYTES_SIZE     4u
#define SECU_ID_SIZE       10u


/* Option Byte Definition                                                    */
/* watchdog enabled, LVD off, 32MHz clock, OCD interface enabled             */
__root __far const unsigned char OptionByte[OPT_BYTES_SIZE] @ 0x00C0u = {
  0xFEu, 0xFFu, 0xE8u, 0x85u,
};

/* Security Byte Definition                                                  */
__root __far const unsigned char SecuIDCode[SECU_ID_SIZE]   @ 0x00C4u = {
  0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u
};

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
#pragma diag_suppress=Pm011
int __low_level_init (void);
#pragma diag_default=Pm011
void R_Systeminit(void);

/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Systeminit
* Description  : This function initializes every macro.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Systeminit(void)
{
    /* Set periperal I/O redirection */
    PIOR0 = 0x00U;
    PIOR1 = 0x00U;
    PIOR2 = 0x00U;
    PIOR3 = 0x00U;
    PIOR4 = 0x00U;
    PIOR5 = 0x00U;
    PIOR6 = 0x00U;
    PIOR7 = 0x00U;
    R_CGC_Get_ResetSource();
    R_CGC_Create();
    R_PORT_Create();
    R_INTC_Create();

    /* Set invalid memory access detection control */
    IAWCTL = 0x00U;
    
    PM6_bit.no6 = 0x00U;               /* use port P6.6 as output              */
    PM6_bit.no7 = 0x00U;               /* use port P6.7 as output              */
    
    /* -------------------------------------------------------------------------*/
    /* Timer Configuration                                                      */
    /* -------------------------------------------------------------------------*/
    TAU0EN  = 1u;                        /* supply input clock                  */
    TT0     = 0x0AFFu;                   /* stop all channels                   */
    TPS0    = 0x0003u;                   /* timer clock frequency               */
    // TPS0 => Select Operation Clocks supplied to each channel from external prescaler
    TMMK00  = 1u;                        /* disable INTTM00 interrupt           */
    TMIF00  = 0u;                        /* clear INTTM00 interrupt flag        */
    TMPR100 = 0u;                        /* Set INTTM00 high priority           */
    TMPR000 = 0u;
  
    /* Channel 0 used as interval timer */
    TMR00   =  0x0000u;  // Select Timer Register 0 Channel 0
    TDR00   =  0xFFFFu;  // Set Timer Data Register to 9C3F (default)
    TO0    &= ~0x0001u;  // Buffer Register of timer output for Channel 0
    TOE0   &= ~0x0001u;  // Enabled timer output for Channel 0

 

    TMIF00  = 0u;                        /* clear INTTM00 interrupt flag        */
    TMMK00 &= 0u;                        /* enable INTTM00 interrupt            */
    //TS0    |= 0x0001u;                 /* start timer TM00                    */
    /* The TSm register is a trigger register that is used to initialize timer 
    count register mn (TCRmn) and start the counting operation of each channel. */
}


/***********************************************************************************************************************
* Function Name:  __low_level_init
* Description  : This function initializes hardware setting.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
#pragma diag_suppress=Pm011
int __low_level_init (void)
#pragma diag_default=Pm011
{
    DI();
    R_Systeminit();
    
    return (1);
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
