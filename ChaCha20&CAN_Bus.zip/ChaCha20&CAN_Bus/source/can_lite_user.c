/* IAR Systems Includes                                                       */
#include <intrinsics.h>
#include <ior5f10ppj.h>
#include <ior5f10ppj_ext.h>
#include <stdio.h>
#include "can_lite.h"
#include "chacha20.h"
#include "dtimer.h"
#include <string.h>

 

#define CAN_GlobalError_Interrupt_vector INTCANGERR_vect
#define CAN0_Transmit_Interrupt_vector INTCAN0TRM_vect
#define CAN0_Error_Interrupt_vector INTCAN0ERR_vect
#define CAN0_RxFIFO_Interrupt_vector INTCANGRFR_vect

 

__interrupt static void CAN_GlobalError_Interrupt(void);
__interrupt static void CAN0_Transmit_Interrupt(void);
__interrupt static void CAN0_Error_Interrupt(void);
__interrupt static void CAN0_RxFIFO_Interrupt(void);

 


#define CHACHA20_KEYSIZE_BIT 256
#define CHACHA20_IVSIZE_BIT 64
uint8_t *convertFrom16To8(uint16_t dataAll);

 


#pragma vector = CAN_GlobalError_Interrupt_vector
__interrupt static void CAN_GlobalError_Interrupt(void)
{
    
    uint8_t transmit_history_buffer_overflow_flag;
      uint8_t FIFO_message_lost_flag;
    uint8_t DLC_error_flag;
    
    transmit_history_buffer_overflow_flag = GERFLL & 0x04;
    FIFO_message_lost_flag = GERFLL &0x02;
    DLC_error_flag = GERFLL &0x01;
    
    CANGERRIF =0;
    P6 =_40_Pn6_OUTPUT_1;
    
    if (transmit_history_buffer_overflow_flag)
    {
        GERFLL &= 0xFC;
        // ERROR HANDLING
    }
    
    if (FIFO_message_lost_flag)
    {
        GERFLL &= 0xFD;
        // ERROR HANDLING
    }
    
    if (DLC_error_flag)
    {
        GERFLL &= 0xFE;
        // ERROR HANDLING
    }
    while(1)
    {
    }

 

}

 

#pragma vector = CAN0_Transmit_Interrupt_vector
__interrupt static void CAN0_Transmit_Interrupt(void)
{
    uint8_t transmit_aborted_flag;
      uint8_t transmit_request_flag;
    
    transmit_aborted_flag = TMSTS0 & 0x10;
    transmit_request_flag = TMSTS0 & 0x08;
    
    CAN0TRMIF = 0;
        
        // this kind of if statement will execute as long as the condition inside is any integer NOT zero
    if (transmit_aborted_flag)
    {
        //handling
    }
    if (transmit_request_flag)
    {
        //msg transmit completed handling
    }
    
}

 

#pragma vector = CAN0_Error_Interrupt_vector
__interrupt static void CAN0_Error_Interrupt(void)
{
    uint8_t arbitration_lost_flag;
      uint8_t bus_lock_flag;
    uint8_t overload_flag;
    uint8_t bus_off_recovery_flag;
      uint8_t bus_off_entry_flag;
    uint8_t error_passive_flag;
    uint8_t error_warning_flag;
      uint8_t bus_error_flag;
    
    arbitration_lost_flag = C0ERFLL &0x80;
    bus_lock_flag = C0ERFLL & 0x40;
    overload_flag = C0ERFLL & 0x20;
    bus_off_recovery_flag = C0ERFLL & 0x10; 
    bus_off_entry_flag = C0ERFLL & 0x08;
    error_passive_flag = C0ERFLL & 0x04;
    error_warning_flag = C0ERFLL & 0x02;
    bus_error_flag = C0ERFLL &0x01;
    
    P6 =_40_Pn6_OUTPUT_1;
    
    if (arbitration_lost_flag)
    {
        //error handling
    }
    if (bus_lock_flag)
    {
        //error handling
    }
    if (overload_flag)
    {
        //error handling
    }
    if (bus_off_recovery_flag)
    {
        //error handling
    }
    if (bus_off_entry_flag)
    {
        //error handling
    }
    if (error_passive_flag)
    {
        //error handling
    }
    if (error_warning_flag)
    {
        //error handling
    }
    if (bus_error_flag)
    {
        //error handling
    }
    while(1);
}

 

// The interrupt below will trigger every message reception if Receive FIFO Buffers are used
#pragma vector = CAN0_RxFIFO_Interrupt_vector
__interrupt static void CAN0_RxFIFO_Interrupt(void)
{
//        uint16_t beforeReception = 0, afterReception = 0;
        
        CANGRFRIF = 0U;                /* clear INTCANGRFR interrupt flag */
        CANGRFRMK = 1U;                /* disable INTCANGRFR operation */
        
//        StartTimer();
//        beforeReception = getTimer00Value();
        
        printf("===Reception Started===\n\n");
        
        uint16_t CAN_RX_DATA[20]={};   // allocate 40 bytes array for the received message    
        uint8_t n = 0, m = 0;
        uint8_t dataMix[40]={};
        uint8_t *dataMixPtr;
        
         while ((RFSTS0L & 0x01) != 0x01)       //check if there is still any unread message
        {
            CAN_RX_DATA[n] = RFDF00;
            CAN_RX_DATA[n+1] = RFDF10;
            CAN_RX_DATA[n+2] = RFDF20;
            CAN_RX_DATA[n+3] = RFDF30;
            RFPCTR0 |= 0xFF;            // this line will increment the read pointer, and label the message in the pointed buffer as "read"
            n += 4;
            Delay_ms(10U);              /*Delay to allow time for assigning data to the array from the RFDF register */
            /* The line above can be commented out when self test mode is used, but still need to check can it be commented out when in normal communication case */
        }  
        // This loop will read and store every message it has received in the buffer
        
        if ((RFSTS0 & 0x04) == 0x04){        // check if there is any FIFO message lost
            RFSTS0 &= 0xFB;                  // clear the message lost flag
            printf("A Message lost has occured!\n");
        }
        
        for (int i = 0; i < 20; i++) 
        {
          dataMixPtr = convertFrom16To8(CAN_RX_DATA[i]);
          dataMix[m] = dataMixPtr[0];
          dataMix[m+1] = *(++dataMixPtr);
          m += 2;
        }
       
        int msglen = strlen((char const*)dataMix);
        
        printf("Received Text: %s\n\n", dataMix);
        print_hex_8("Received Text Hex", dataMix, msglen);
        
            /* ---------- Chacha20 Initialization -------------------- */
    
        /* key and iv setup */
        // 32-byte key
        uint8_t key[32] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                          0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};                       
        // 8-byte iv or nonce
        uint8_t iv[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    
        /* clear key-length and IV-size */
        uint32_t keysize = CHACHA20_KEYSIZE_BIT;
        uint32_t ivsize = CHACHA20_IVSIZE_BIT;
    
        /* define context-struct */
        Chacha20_ctx x;
    
        /* initialize state */
        Chacha20_keysetup(&x, key, keysize, ivsize);
        Chacha20_ivsetup(&x, iv);
       
        Chacha20_decrypt_bytes(&x, dataMix, dataMix, msglen);
        
        printf("\nDecrypted Message Text: %s\n\n", dataMix);
        print_hex_8("Decrypted Message Hex", dataMix, msglen);
        
        printf("\n===Reception Ended===\n\n\n");
        
        RFSTS0 &= 0xF7;                      /*clear response reception successful flag*/
        while((RFSTS0 & 0x08) == 0x08);     // wait until the flag is cleared
        
//        afterReception = getTimer00Value();
//        printf("Reception Clock Cycle: %u clocks\n", beforeReception - afterReception);
        
        CANGRFRMK = 0U;                /* enable INTCANGRFR operation */
}

 

uint8_t *convertFrom16To8(uint16_t dataAll) {
    static uint8_t arrayData[2] = { 0x00, 0x00 };
    arrayData[1] = dataAll & 0xff;
    arrayData[0] = (dataAll >> 8) & 0xff;
    return arrayData;
}