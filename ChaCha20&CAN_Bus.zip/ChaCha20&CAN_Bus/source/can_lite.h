#ifndef RSCAN_H
#define RSCAN_H

#include "r_cg_macrodriver.h"
#include "r_cg_port.h"
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
* Function Name: CAN-Init
* Description  : This function initialise can lite bus.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CAN_Init(void);

/***********************************************************************************************************************
* Function Name: RxRule_Set
* Description  : This function set up the receive rule of can lite bus.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void RxRule_Set(void);

/***********************************************************************************************************************
* Function Name: CAN_TxBuffer0
* Description  : This function transmits the data from the buffer to the Bus
* Arguments    : TxData1        Data to be transmitted byte 1 & 2
                 TxData2        Data byte 3 & 4
                 TxData3        Data byte 5 & 6
                 TxData4        Data byte 7 & 8
                 TxID           Data ID
* Return Value : None
***********************************************************************************************************************/
void CAN_TxBuffer0(uint16_t TxData1,uint16_t TxData2,uint16_t TxData3,uint16_t TxData4,uint16_t txID);

/***********************************************************************************************************************
* Function Name: CAN_SelfTest0
* Description  : This function sets up the Self Test Mode 0 (External Feedback Mode)
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CAN_SelfTest0(void);

/***********************************************************************************************************************
* Function Name: print_hex
* Description  : This function prints it's arguments in hexadecimal format
* Arguments    : msg            string to be printed before the data
                 data           array of data
                 length         length of data in bytes
* Return Value : None
***********************************************************************************************************************/
void print_hex_16(const char *msg, const uint16_t *data, int length);
void print_hex_8(const char *msg, const unsigned char *data, int length);

/***********************************************************************************************************************
* Function Name: Delay_ms
* Description  : This function is to produce delay
* Arguments    : i      Duration of delay in ms
* Return Value : None
***********************************************************************************************************************/
void Delay_ms(uint8_t i);

#endif